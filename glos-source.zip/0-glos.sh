#!/bin/sh

#Run glos-Start Script

sh 1-*
sh 2-*
sh 3-*
sh 4-*
sh 5-*
sh 6-*
sh 7-*
sh 8-*
sh 9-*
sh 10-*

